from app import app, db
from app.models import Book

def seed_books():
    books = [
        Book(title='To Kill a Mockingbird', author='Harper Lee', available=True),
        Book(title='1984', author='George Orwell', available=True),
        Book(title='The Great Gatsby', author='F. Scott Fitzgerald', available=True),
        Book(title='The Catcher in the Rye', author='J.D. Salinger', available=True)
    ]
    db.session.add_all(books)
    db.session.commit()

if __name__ == "__main__":
    with app.app_context():
        seed_books()
        print("Books have been seeded.")
