from app import app, db
import unittest

class BasicTests(unittest.TestCase):

    def setUp(self):
        # Set up the application context and test client
        self.app = app
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()

        # Create all tables
        db.create_all()

    def tearDown(self):
        # Remove the application context
        self.app_context.pop()

    def test_home_page(self):
        # Ensure that the home page loads correctly
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Welcome to the Library available/login System', response.data)

if __name__ == "__main__":
    unittest.main()
