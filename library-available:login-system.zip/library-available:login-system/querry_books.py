from app import app, db
from app.models import Book

with app.app_context():
    books = Book.query.all()
    for book in books:
        print(book)
